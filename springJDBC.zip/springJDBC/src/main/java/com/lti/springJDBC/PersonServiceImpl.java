package com.lti.springJDBC;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("personService")
public class PersonServiceImpl implements PersonService{
   @Autowired
	PersonDao personDao;
	
	public void addPerson(Person person) {
		// TODO Auto-generated method stub
		personDao.addPerson(person);
		
	}

	public void editPerson(Person person, int personId) {
		// TODO Auto-generated method stub
		personDao.editPerson(person, personId);
	}

	public void deletePerson(int personId) {
		// TODO Auto-generated method stub
		personDao.deletePerson(personId);
		
		
	}

	public Person find(int personId) {
		return personDao.find(personId);
	}

	public List<Person> findAll() {
		// TODO Auto-generated method stub
		return personDao.findAll();
		
	}

}
