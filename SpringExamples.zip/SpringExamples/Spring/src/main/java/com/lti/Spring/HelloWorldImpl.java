package com.lti.Spring;

public class HelloWorldImpl implements HelloWorld{

	public void printMessage(String message) {
		
		System.out.println(message);
		
	}

	
}
