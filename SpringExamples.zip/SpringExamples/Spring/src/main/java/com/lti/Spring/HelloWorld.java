package com.lti.Spring;

public interface HelloWorld 
{

	public void  printMessage(String message);
	
	
}
