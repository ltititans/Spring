package com.lti.springDI;

public interface Department {
void showDepartmentinfo();

}
