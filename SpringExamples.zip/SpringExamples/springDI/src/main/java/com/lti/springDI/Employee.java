package com.lti.springDI;

public interface Employee {

	
	void showEmployeeInfo();
}
