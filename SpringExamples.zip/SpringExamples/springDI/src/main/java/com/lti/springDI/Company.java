package com.lti.springDI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Company {

	private Employee employee;
	private Department department;
	
	// Constructor based DI(calling through constructor)
	
	@Autowired
	public Company(Employee employee) {
		super();
		this.employee = employee;
	}
	
	public void showEmployeeDetails()
	{
		employee.showEmployeeInfo();
	}

	
	// Setter method based DI
	
	@Autowired
	public void setDepartment(Department department) {
		this.department = department;
	}
 
	public void showDepartmentInfo()
	{
		department.showDepartmentinfo();
	}
	
	
	
	
	
}
