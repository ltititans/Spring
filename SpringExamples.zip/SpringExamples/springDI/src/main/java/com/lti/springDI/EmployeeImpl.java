package com.lti.springDI;

import java.util.Scanner;

public class EmployeeImpl implements Employee{

	public void showEmployeeInfo() {
		// TODO Auto-generated method stub

		int numbers;
		Scanner ob=new Scanner(System.in);
		System.out.println("Enter Max numbers");
		numbers=ob.nextInt();
	    int i, count = 0;

	    for (i = 0; i < numbers; i++) {

	        System.out.print(i + " ");
	        count++;

	       
	    }
	}
	}


