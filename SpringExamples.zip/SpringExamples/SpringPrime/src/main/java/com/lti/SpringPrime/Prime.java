package com.lti.SpringPrime;

public interface Prime {

	public void printMessage();
}
