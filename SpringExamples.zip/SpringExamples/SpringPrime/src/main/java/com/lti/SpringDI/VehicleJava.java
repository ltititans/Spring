package com.lti.SpringDI;

public class VehicleJava {
	public static void main(String h[]){
		Wheel w=new Travel();
			
	}

}
