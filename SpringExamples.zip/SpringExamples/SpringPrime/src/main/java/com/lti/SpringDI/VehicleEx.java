package com.lti.SpringDI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class VehicleEx {

	
	public static void main(String[] args) {
		ApplicationContext dx=new ClassPathXmlApplicationContext("applicationcontext.xml");
		Car v=(Car)dx.getBean("car");
		
		v.move();
	}
}
