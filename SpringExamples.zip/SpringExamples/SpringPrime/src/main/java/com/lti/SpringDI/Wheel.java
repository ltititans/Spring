package com.lti.SpringDI;

public interface Wheel {
void rotate();

}
