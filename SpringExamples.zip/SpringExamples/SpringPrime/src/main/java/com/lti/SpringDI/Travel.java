package com.lti.SpringDI;

public class Travel implements Wheel {
	

	public void rotate() {
		System.out.println("Rotate");
		
	}

	
}
