package com.lti.set;


import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

public class CollectionsBean {
	@Autowired
	private Set<String> nameList;
		
		public void printNameList(){
			System.out.println(nameList);
		}
}
