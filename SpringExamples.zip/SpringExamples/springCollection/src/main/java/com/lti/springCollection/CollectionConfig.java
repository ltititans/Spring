package com.lti.springCollection;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;

public class CollectionConfig {

	@Bean
	public CollectionsBean getCollection(){
		return new CollectionsBean();
		
	}
	@Bean
	public List<String> nameList(){
		return Arrays.asList("John","Adam","Harry");
		
	}
}
