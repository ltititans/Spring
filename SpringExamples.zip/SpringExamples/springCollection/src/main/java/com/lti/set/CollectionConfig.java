package com.lti.set;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.annotation.Bean;



public class CollectionConfig {
	@Bean
	public CollectionsBean getCollection(){
		return new CollectionsBean();
		
	}
	@Bean
	public Set<String> nameList(){
		Set<String> s=new HashSet<String>();
		
		s.add("abc");
		s.add("msd");
		return s;
		
		
	}
}
