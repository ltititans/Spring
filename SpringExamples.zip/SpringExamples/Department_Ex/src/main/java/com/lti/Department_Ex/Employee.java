package com.lti.Department_Ex;

public class Employee implements Department {

	public void salary() {
		// TODO Auto-generated method stub
		System.out.println("Salary is 28,0000000");
	}
	

}
