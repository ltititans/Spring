package com.lti.Department_Ex;

public interface Department {
void salary();
	
}
