package com.lti.Department_Ex;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Emp_main {
public static void main(String[] args) {
	ApplicationContext dx=new ClassPathXmlApplicationContext("beans.xml");

	Employee_Details ed=(Employee_Details)dx.getBean("emp");
ed.salary_details();
}

}
