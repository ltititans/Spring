package com.lti.Trainee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.Department_Ex.Employee_Details;

public class App {
	public static void main(String[] args) {
		ApplicationContext dx=new ClassPathXmlApplicationContext("beans.xml");

		Trainee obj=(Trainee)dx.getBean("tr");
	System.out.println(obj);
	}

}
