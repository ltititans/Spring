package com.lti.Department_Ex;



public class Employee_Details {

	Department d;
	
	
	
	public Department getDepartment(){
		return d;
	}
	public void setDepartment(Department d){
		this.d=d;
	}

	public void salary_details(){
		d.salary();
		
	}
	
}

