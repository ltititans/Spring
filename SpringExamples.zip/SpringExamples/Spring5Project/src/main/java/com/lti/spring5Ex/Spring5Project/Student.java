package com.lti.spring5Ex.Spring5Project;

public class Student {

	int id;
	String name;
	Country c;
	public Country getC() {
		return c;
	}
	public void setC(Country c) {
		this.c = c;
	}
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Student(int id, String name, Country c) {
		super();
		this.id = id;
		this.name = name;
		this.c = c;
	}
	public Student(String name) {
		super();
		this.name = name;
	}
	public Student(int id) {
		super();
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", c=" + c + "]";
	}
	public Student(Country c) {
		super();
		this.c = c;
	}
	
}
