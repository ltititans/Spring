package com.lti.spring5Ex.Spring5Project;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration

public class ApplicationConfiguration {
@Bean(name="studentObj2")	
public Student getC(){
	return new Student(new Country("India"));
}
	@Bean(name="studentObj")
	public Student getId() {
		return new Student(20);
	}
	@Bean(name="studentObj1")
	public Student getName() {
		return new Student("Niku");
	}
	
	
}
