package com.lti.spring5Ex.Spring5Project;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	@SuppressWarnings("resource")
		ApplicationContext appContext=new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
    	Student studentObj2=(Student) appContext.getBean("studentObj2");
    	
    	Student studentObj=(Student) appContext.getBean("studentObj");
    	
    	Student studentObj1=(Student) appContext.getBean("studentObj1");
    	
    	Country countryName=studentObj2.getC();
    	System.out.println("Country="+countryName);
    	String studentName=studentObj1.getName();
    	int studentId=studentObj.getId();
    
    	System.out.println("Student ID is =" +studentId);
    	System.out.println("Student Name is =" +studentName);
    	System.out.println("Student Country is =" +countryName);
}
}
