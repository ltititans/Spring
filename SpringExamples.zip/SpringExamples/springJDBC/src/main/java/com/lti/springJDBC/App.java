package com.lti.springJDBC;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        PersonService personService = (PersonService) context.getBean("personService");
        
        
        Person Kapil = new Person(4, "Kapil", "Dev", 64);
        Person Sachin = new Person(5, "Sachin", "Tendulkar", 44);
        Person Virat = new Person(6, "Virat", "Kohli", 31);
        
        
        personService.addPerson(Kapil);
        personService.addPerson(Sachin);
        personService.addPerson(Virat);
        
        System.out.println("Find All");
        
        List < Person > persons =personService.findAll();
        for(Person person :persons)
        {
        	System.out.println(person);
        }
        
        System.out.println("Delete person Id = 4");
        int deleteMe = 4;
        personService.deletePerson(deleteMe);
        context.close();
        
        System.out.println("Find person Id = 6");
        Person person=personService.find(6);
        System.out.println(person);
        
        
        System.out.println("Find All Again");
        persons=personService.findAll();
        for(Person p:persons){
        	 System.out.println(p);
        	 }
        
        System.out.println("Update person Id = 5");
        int updateMe = 5;
        personService.editPerson(Sachin, updateMe);
        context.close();
    }
}
