package com.lti.springJDBC;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository //mentions that the class provides mechanism for database crud functionalities
@Qualifier("personDao")
//qualifier mentions that if we have the same name of id to avoid the conflict of the same names we use @Qualifier

public class PersonDaoImpl implements PersonDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public void addPerson(Person person) {
		jdbcTemplate.update("insert into person(person_id,first_name,"+ "last_name,age) values(?,?,?,?)",
				person.getPersonId(), person.getFirstName(), person.getLastName(), person.getAge());
				System.out.println("Person Added !!");
		
	}

	public void editPerson(Person person, int personId) {
		// TODO Auto-generated method stub
		
		jdbcTemplate.update("update person set first_name=?, " + " last_name= ?, age = ? where person_id= ? ",
				person.getFirstName(), person.getLastName(), person.getAge(), personId);
		
		System.out.println("Persons updated");
		
		
	}

	public void deletePerson(int personId) {
		// TODO Auto-generated method stub
		
		jdbcTemplate.update("delete from person where person_id = ?" , personId);
		System.out.println("Person Deleted!!");
		
	}
	
	@SuppressWarnings("unchecked")
	public Person find(int personId) 
	{
		// TODO Auto-generated method stub
		@SuppressWarnings("rawtypes")
		Person person =(Person) jdbcTemplate.queryForObject("select * from " + "person where person_id = ?",
				new Object[] { personId}, new BeanPropertyRowMapper(Person.class));
		
		return person;
	}

	
	@SuppressWarnings("rawtypes")
	public List<Person> findAll() {
		
		@SuppressWarnings("unchecked")
		List<Person> persons = jdbcTemplate.query("select * from person",
				new BeanPropertyRowMapper(Person.class));
	
		return persons;
		
	}

}
